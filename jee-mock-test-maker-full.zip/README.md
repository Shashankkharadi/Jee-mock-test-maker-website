# JEE Mock Test Maker Full MVP Scaffold

Includes frontend, backend, database and deployment starter structure.